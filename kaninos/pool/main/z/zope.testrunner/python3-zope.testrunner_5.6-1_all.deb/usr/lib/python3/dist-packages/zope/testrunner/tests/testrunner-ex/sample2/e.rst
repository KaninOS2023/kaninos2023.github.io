    >>> def f():
    ...     return x
   
    >>> f()
