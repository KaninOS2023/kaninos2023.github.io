This is a sample doctest

    >>> x=1
    >>> x
    1

Blah blah blah

    >>> x
    1

Blah blah blah

    >>> x
    1

Blah blah blah

    >>> x
    1
