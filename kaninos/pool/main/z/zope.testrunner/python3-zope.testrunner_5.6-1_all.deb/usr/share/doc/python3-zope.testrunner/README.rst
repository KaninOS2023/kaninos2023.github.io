=================
 zope.testrunner
=================

.. image:: https://img.shields.io/pypi/v/zope.testrunner.svg
        :target: https://pypi.org/project/zope.testrunner/
        :alt: Latest release

.. image:: https://img.shields.io/pypi/pyversions/zope.testrunner.svg
        :target: https://pypi.org/project/zope.testrunner/
        :alt: Supported Python versions

.. image:: https://github.com/zopefoundation/zope.testrunner/actions/workflows/tests.yml/badge.svg
        :target: https://github.com/zopefoundation/zope.testrunner/actions/workflows/tests.yml

.. image:: https://coveralls.io/repos/github/zopefoundation/zope.testrunner/badge.svg?branch=master
        :target: https://coveralls.io/github/zopefoundation/zope.testrunner?branch=master

.. image:: https://readthedocs.org/projects/zopetestrunner/badge/?version=latest
        :target: https://zopetestrunner.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. contents::

This package provides a flexible test runner with layer support.

Detailed documentation is hosted at https://zopetestrunner.readthedocs.io
