# Copyright (c) FlatBuffers Contributors, Apache License 2.0

# Copied from (master branch, 05/29/2022):
# * https://github.com/google/flatbuffers/blob/master/reflection/reflection.fbs
# * https://github.com/google/flatbuffers/tree/master/python/flatbuffers/reflection
