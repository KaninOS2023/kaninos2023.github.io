#!/usr/bin/env python

from __future__ import print_function

import os, random, re, sys

try:
    from cStringIO import StringIO as BytesIO
except ImportError:
    from io import BytesIO

import unittest

global VERBOSE
VERBOSE=False

import zfec

from base64 import b32encode
def ab(x): # debuggery
    if len(x) >= 3:
        return "%s:%s" % (len(x), b32encode(x[-3:]),)
    elif len(x) == 2:
        return "%s:%s" % (len(x), b32encode(x[-2:]),)
    elif len(x) == 1:
        return "%s:%s" % (len(x), b32encode(x[-1:]),)
    elif len(x) == 0:
        return "%s:%s" % (len(x), "--empty--",)

def randstr(n):
    return os.urandom(n)

def _h(k, m, ss):
    encer = zfec.Encoder(k, m)
    nums_and_blocks = list(enumerate(encer.encode(ss)))
    assert isinstance(nums_and_blocks, list), nums_and_blocks
    assert len(nums_and_blocks) == m, (len(nums_and_blocks), m,)
    nums_and_blocks = random.sample(nums_and_blocks, k)
    blocks = [ x[1] for x in nums_and_blocks ]
    nums = [ x[0] for x in nums_and_blocks ]
    decer = zfec.Decoder(k, m)
    decoded = decer.decode(blocks, nums)
    assert len(decoded) == len(ss), (len(decoded), len(ss),)
    assert tuple([str(s) for s in decoded]) == tuple([str(s) for s in ss]), (tuple([ab(str(s)) for s in decoded]), tuple([ab(str(s)) for s in ss]),)

def _help_test_random():
    m = random.randrange(1, 257)
    k = random.randrange(1, m+1)
    l = random.randrange(0, 2**9)
    ss = [ randstr(l//k) for x in range(k) ]
    _h(k, m, ss)

def _help_test_random_with_l(l):
    m = random.randrange(1, 257)
    k = random.randrange(1, m+1)
    ss = [ randstr(l//k) for x in range(k) ]
    _h(k, m, ss)

def _h_easy(k, m, s):
    encer = zfec.easyfec.Encoder(k, m)
    nums_and_blocks = list(enumerate(encer.encode(s)))
    assert isinstance(nums_and_blocks, list), nums_and_blocks
    assert len(nums_and_blocks) == m, (len(nums_and_blocks), m,)
    nums_and_blocks = random.sample(nums_and_blocks, k)
    blocks = [ x[1] for x in nums_and_blocks ]
    nums = [ x[0] for x in nums_and_blocks ]
    decer = zfec.easyfec.Decoder(k, m)

    decodeds = decer.decode(blocks, nums, padlen=k*len(blocks[0]) - len(s))
    assert len(decodeds) == len(s), (ab(decodeds), ab(s), k, m)
    assert decodeds == s, (ab(decodeds), ab(s),)

def _help_test_random_easy():
    m = random.randrange(1, 257)
    k = random.randrange(1, m+1)
    l = random.randrange(0, 2**9)
    s = randstr(l)
    _h_easy(k, m, s)

def _help_test_random_with_l_easy(l):
    m = random.randrange(1, 257)
    k = random.randrange(1, m+1)
    s = randstr(l)
    _h_easy(k, m, s)

class ZFecTest(unittest.TestCase):
    def test_instantiate_encoder_no_args(self):
        try:
            e = zfec.Encoder()
            del e
        except TypeError:
            # Okay, so that's because we're required to pass constructor args.
            pass
        else:
            # Oops, it should have raised an exception.
            self.fail("Should have raised exception from incorrect arguments to constructor.")

    def test_instantiate_decoder_no_args(self):
        try:
            e = zfec.Decoder()
            del e
        except TypeError:
            # Okay, so that's because we're required to pass constructor args.
            pass
        else:
            # Oops, it should have raised an exception.
            self.fail("Should have raised exception from incorrect arguments to constructor.")

    def test_from_agl_c(self):
        self.assertTrue(zfec._fec.test_from_agl())

    def test_from_agl_py(self):
        e = zfec.Encoder(3, 5)
        b0 = b'\x01'*8 ; b1 = b'\x02'*8 ; b2 = b'\x03'*8
        # print "_from_py before encoding:"
        # print "b0: %s, b1: %s, b2: %s" % tuple(base64.b16encode(x) for x in [b0, b1, b2])

        b3, b4 = e.encode([b0, b1, b2], (3, 4))
        # print "after encoding:"
        # print "b3: %s, b4: %s" % tuple(base64.b16encode(x) for x in [b3, b4])

        d = zfec.Decoder(3, 5)
        r0, r1, r2 = d.decode((b2, b3, b4), (1, 2, 3))

        # print "after decoding:"
        # print "b0: %s, b1: %s" % tuple(base64.b16encode(x) for x in [b0, b1])

    def test_small(self):
        for i in range(16):
            _help_test_random_with_l(i)
        if VERBOSE:
            print("%d randomized tests pass." % (i+1))

    def test_random(self):
        for i in range(3):
            _help_test_random()
        if VERBOSE:
            print("%d randomized tests pass." % (i+1))

    def test_bad_args_construct_decoder(self):
        try:
            zfec.Decoder(-1, -1)
        except zfec.Error as e:
            assert "argument is required to be greater than or equal to 1" in str(e), e
        else:
            self.fail("Should have gotten an exception from out-of-range arguments.")

        try:
            zfec.Decoder(1, 257)
        except zfec.Error as e:
            assert "argument is required to be less than or equal to 256" in str(e), e
        else:
            self.fail("Should have gotten an exception from out-of-range arguments.")

        try:
            zfec.Decoder(3, 2)
        except zfec.Error as e:
            assert "first argument is required to be less than or equal to the second argument" in str(e), e
        else:
            self.fail("Should have gotten an exception from out-of-range arguments.")

    def test_bad_args_construct_encoder(self):
        try:
            zfec.Encoder(-1, -1)
        except zfec.Error as e:
            assert "argument is required to be greater than or equal to 1" in str(e), e
        else:
            self.fail("Should have gotten an exception from out-of-range arguments.")

        try:
            zfec.Encoder(1, 257)
        except zfec.Error as e:
            assert "argument is required to be less than or equal to 256" in str(e), e
        else:
            self.fail("Should have gotten an exception from out-of-range arguments.")

    def test_bad_args_dec(self):
        decer = zfec.Decoder(2, 4)

        try:
            decer.decode(98, []) # first argument is not a sequence
        except TypeError as e:
            assert "First argument was not a sequence" in str(e), e
        else:
            self.fail("Should have gotten TypeError for wrong type of second argument.")

        try:
            decer.decode(["a", "b", ], ["c", "d",])
        except zfec.Error as e:
            assert "Precondition violation: second argument is required to contain int" in str(e), e
        else:
            self.fail("Should have gotten zfec.Error for wrong type of second argument.")

        try:
            decer.decode(["a", "b", ], 98) # not a sequence at all
        except TypeError as e:
            assert "Second argument was not a sequence" in str(e), e
        else:
            self.fail("Should have gotten TypeError for wrong type of second argument.")

class EasyFecTest(unittest.TestCase):
    def test_small(self):
        for i in range(16):
            _help_test_random_with_l_easy(i)
        if VERBOSE:
            print("%d randomized tests pass." % (i+1))

    def test_random(self):
        for i in range(3):
            _help_test_random_easy()
        if VERBOSE:
            print("%d randomized tests pass." % (i+1))

    def test_bad_args_dec(self):
        decer = zfec.easyfec.Decoder(2, 4)

        try:
            decer.decode(98, [0, 1], 0) # first argument is not a sequence
        except TypeError as e:
            assert "First argument was not a sequence" in str(e), e
        else:
            self.fail("Should have gotten TypeError for wrong type of second argument.")

        try:
            decer.decode("ab", ["c", "d",], 0)
        except zfec.Error as e:
            assert "Precondition violation: second argument is required to contain int" in str(e), e
        else:
            self.fail("Should have gotten zfec.Error for wrong type of second argument.")

        try:
            decer.decode("ab", 98, 0) # not a sequence at all
        except TypeError as e:
            assert "Second argument was not a sequence" in str(e), e
        else:
            self.fail("Should have gotten TypeError for wrong type of second argument.")

if __name__ == "__main__":
    unittest.main()
