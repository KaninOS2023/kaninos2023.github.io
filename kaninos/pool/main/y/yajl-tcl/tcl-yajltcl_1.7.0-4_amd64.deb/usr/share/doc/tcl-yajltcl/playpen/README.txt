

various little proto tests and experiments - perhaps some useful examples


