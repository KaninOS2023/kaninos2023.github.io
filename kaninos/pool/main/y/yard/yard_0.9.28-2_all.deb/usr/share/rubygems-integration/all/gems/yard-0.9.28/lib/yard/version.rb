
# frozen_string_literal: true

module YARD
  VERSION = '0.9.28'
end
