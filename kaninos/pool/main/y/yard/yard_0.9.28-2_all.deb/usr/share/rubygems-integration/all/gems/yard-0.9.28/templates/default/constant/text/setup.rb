# frozen_string_literal: true
def init
  sections :header, [T('docstring')]
end
