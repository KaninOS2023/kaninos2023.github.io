# frozen_string_literal: true
include T('default/onefile/html')

def init
  sections :layout, [:toc, :files]
end
