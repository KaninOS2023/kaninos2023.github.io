# frozen_string_literal: true
include T('default/layout/html')

def init
  sections :library_list, [:title, :listing, :footer]
end
