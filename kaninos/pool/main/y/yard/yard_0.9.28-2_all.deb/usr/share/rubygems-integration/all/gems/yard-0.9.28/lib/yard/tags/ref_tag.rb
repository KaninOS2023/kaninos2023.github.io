# frozen_string_literal: true
module YARD
  module Tags
    module RefTag
      attr_accessor :owner
    end
  end
end
