from yoyo.scripts.main import main

main()
